<?php
define("DB_HOST","localhost");
define("DB_USER","id9969258_db_ibnu");
define("DB_PASSWORD","db_ibnu");
define("DB_NAME","id9969258_db_ibnu");

// echo DB_HOST;
